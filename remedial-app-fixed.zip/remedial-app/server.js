'use strict';
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const ADMIN_IDS = new Set((process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(x => x.trim()).filter(Boolean));
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'remedial-data');
const UPLOAD_DIR = path.join(DATA_DIR, 'receipts');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!BOT_TOKEN) console.warn('WARNING: TELEGRAM_BOT_TOKEN is not set. API authentication will reject requests.');
if (!ADMIN_IDS.size) console.warn('WARNING: ADMIN_TELEGRAM_IDS is not set. No Telegram account can use the admin dashboard.');

app.use(express.json({ limit: '8mb' }));
app.use(express.static(__dirname, { index: 'index.html' }));
const db = new Database(path.join(DATA_DIR, 'remedial.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 telegram_id TEXT PRIMARY KEY, username TEXT, profile_json TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL, trial_ends_at TEXT NOT NULL, subscription_expires_at TEXT,
 is_admin INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS payments (
 id TEXT PRIMARY KEY, telegram_id TEXT NOT NULL, method TEXT NOT NULL, amount INTEGER NOT NULL,
 tx_id TEXT NOT NULL UNIQUE, receipt_path TEXT NOT NULL, receipt_type TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL, reviewed_at TEXT,
 reviewed_by TEXT, rejection_reason TEXT,
 FOREIGN KEY(telegram_id) REFERENCES users(telegram_id)
);
CREATE TABLE IF NOT EXISTS scores (
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT NOT NULL, score INTEGER NOT NULL,
 total INTEGER NOT NULL, subject TEXT NOT NULL, created_at TEXT NOT NULL
);
`);
const nowIso = () => new Date().toISOString();
const plusMs = (date, ms) => new Date(date.getTime() + ms).toISOString();
function safeEqualHex(a, b) {
  try { const aa = Buffer.from(a, 'hex'), bb = Buffer.from(b, 'hex'); return aa.length === bb.length && crypto.timingSafeEqual(aa, bb); }
  catch { return false; }
}
function telegramUser(req, res, next) {
  if (!BOT_TOKEN) return res.status(503).json({ error: 'server_not_configured' });
  const initData = req.get('X-Telegram-Init-Data') || '';
  if (!initData) return res.status(401).json({ error: 'telegram_auth_required' });
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  const authDate = Number(params.get('auth_date') || 0);
  if (!hash || !authDate || Math.abs(Date.now()/1000 - authDate) > 86400) return res.status(401).json({ error: 'invalid_or_expired_telegram_auth' });
  const checkString = [...params.entries()].filter(([k]) => k !== 'hash').sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
  const calculated = crypto.createHmac('sha256', secret).update(checkString).digest('hex');
  if (!safeEqualHex(calculated, hash)) return res.status(401).json({ error: 'invalid_telegram_signature' });
  let user;
  try { user = JSON.parse(params.get('user') || 'null'); } catch { user = null; }
  if (!user || !user.id) return res.status(401).json({ error: 'telegram_user_missing' });
  req.tgUser = user;
  req.telegramId = String(user.id);
  req.isAdmin = ADMIN_IDS.has(req.telegramId);
  next();
}
function ensureUser(req) {
  const u = req.tgUser;
  const existing = db.prepare('SELECT * FROM users WHERE telegram_id=?').get(req.telegramId);
  if (!existing) {
    const created = new Date();
    db.prepare('INSERT INTO users (telegram_id, username, profile_json, created_at, trial_ends_at, is_admin) VALUES (?,?,?,?,?,?)')
      .run(req.telegramId, u.username || '', JSON.stringify({ name: [u.first_name,u.last_name].filter(Boolean).join(' ') }), created.toISOString(), created.toISOString(), req.isAdmin ? 1 : 0);
  } else if (!!existing.is_admin !== req.isAdmin) {
    db.prepare('UPDATE users SET is_admin=? WHERE telegram_id=?').run(req.isAdmin ? 1 : 0, req.telegramId);
  }
  return db.prepare('SELECT * FROM users WHERE telegram_id=?').get(req.telegramId);
}
function requireAdmin(req, res, next) {
  if (!req.isAdmin) return res.status(403).json({ error: 'admin_required' });
  next();
}
function parsedProfile(row) { try { return JSON.parse(row.profile_json || '{}'); } catch { return {}; } }
app.use('/api', telegramUser);

app.get('/api/me', (req,res) => {
  const row = ensureUser(req); const profile = parsedProfile(row); const now = Date.now();
  const premium = !!row.subscription_expires_at && new Date(row.subscription_expires_at).getTime() > now;
  const trialActive = new Date(row.trial_ends_at).getTime() > now;
  const payment = db.prepare('SELECT status FROM payments WHERE telegram_id=? ORDER BY created_at DESC LIMIT 1').get(req.telegramId);
  res.json({ registered: !!(profile.phone && profile.school), profile, premium, trialActive, trialEndsAt: row.trial_ends_at, subscriptionExpiresAt: row.subscription_expires_at, status: payment?.status || '', isAdmin: req.isAdmin });
});

app.post('/api/register', (req,res) => {
  const row = ensureUser(req); const p = req.body || {};
  const name = String(p.name || '').trim().replace(/\s+/g,' ');
  const phone = String(p.phone || '').trim();
  const stream = String(p.stream || ''); const region = String(p.region || ''); const school = String(p.school || '').trim();
  if (name.length < 3 || name.length > 60 || !/^\+251[79]\d{8}$/.test(phone) || !['natural','social'].includes(stream) || !region || school.length < 2 || school.length > 80) return res.status(400).json({ error: 'invalid_profile' });
  const profile = { name, phone, stream, region, school };
  const trialEndsAt = !(parsedProfile(row).phone && parsedProfile(row).school) ? plusMs(new Date(), 48*60*60*1000) : row.trial_ends_at;
  db.prepare('UPDATE users SET profile_json=?, username=?, is_admin=?, trial_ends_at=? WHERE telegram_id=?').run(JSON.stringify(profile), req.tgUser.username || '', req.isAdmin ? 1 : 0, trialEndsAt, req.telegramId);
  res.json({ ok: true, profile });
});

app.post('/api/payments', (req,res) => {
  const row = ensureUser(req); const body = req.body || {};
  const method = String(body.method || ''); const amount = Number(body.amount);
  const txId = String(body.txId || '').trim().toUpperCase(); const dataUrl = String(body.receiptDataUrl || '');
  if (!(parsedProfile(row).phone && parsedProfile(row).school)) return res.status(400).json({ error: 'not_registered' });
  if (row.subscription_expires_at && new Date(row.subscription_expires_at).getTime() > Date.now()) return res.status(400).json({ error: 'already_premium' });
  if (!['telebirr','cbe','abyssinia'].includes(method) || amount !== 200) return res.status(400).json({ error: 'invalid_payment_details' });
  if (!/^[A-Za-z0-9\-/ ]{4,40}$/.test(txId)) return res.status(400).json({ error: 'bad_tx' });
  const pending = db.prepare("SELECT id FROM payments WHERE telegram_id=? AND status='pending'").get(req.telegramId);
  if (pending) return res.status(409).json({ error: 'already_pending' });
  const duplicate = db.prepare('SELECT id FROM payments WHERE tx_id=?').get(txId);
  if (duplicate) return res.status(409).json({ error: 'duplicate_tx' });
  const m = dataUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!m) return res.status(400).json({ error: 'receipt_required' });
  const bytes = Buffer.from(m[2], 'base64');
  if (!bytes.length || bytes.length > 5*1024*1024) return res.status(400).json({ error: 'receipt_too_large' });
  const ext = ({'image/jpeg':'jpg','image/png':'png','image/webp':'webp'})[m[1]];
  const id = crypto.randomUUID(); const filename = `${id}.${ext}`; fs.writeFileSync(path.join(UPLOAD_DIR, filename), bytes, { flag: 'wx' });
  try {
    db.prepare('INSERT INTO payments (id,telegram_id,method,amount,tx_id,receipt_path,receipt_type,status,created_at) VALUES (?,?,?,?,?,?,?,\'pending\',?)')
      .run(id, req.telegramId, method, 200, txId, filename, m[1], nowIso());
  } catch (e) { fs.unlinkSync(path.join(UPLOAD_DIR, filename)); if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'duplicate_tx' }); throw e; }
  res.json({ ok: true, status: 'pending', paymentId: id });
});

app.post('/api/score', (req,res) => {
  ensureUser(req); const score = Number(req.body?.score), total = Number(req.body?.total), subject = String(req.body?.subject || '').slice(0,80);
  if (!Number.isInteger(score) || !Number.isInteger(total) || total < 1 || score < 0 || score > total) return res.status(400).json({ error: 'invalid_score' });
  db.prepare('INSERT INTO scores (telegram_id,score,total,subject,created_at) VALUES (?,?,?,?,?)').run(req.telegramId,score,total,subject,nowIso());
  res.json({ ok: true });
});

app.get('/api/admin/summary', requireAdmin, (req,res) => {
  const now = nowIso();
  const students = db.prepare('SELECT COUNT(*) n FROM users').get().n;
  const trial = db.prepare('SELECT COUNT(*) n FROM users WHERE trial_ends_at>? AND (subscription_expires_at IS NULL OR subscription_expires_at<=?)').get(now,now).n;
  const activeSubscribers = db.prepare('SELECT COUNT(*) n FROM users WHERE subscription_expires_at>?').get(now).n;
  const expiredSubscriptions = db.prepare('SELECT COUNT(*) n FROM users WHERE subscription_expires_at IS NOT NULL AND subscription_expires_at<=?').get(now).n;
  const pendingPayments = db.prepare("SELECT COUNT(*) n FROM payments WHERE status='pending'").get().n;
  const approvedPayments = db.prepare("SELECT COUNT(*) n FROM payments WHERE status='approved'").get().n;
  res.json({ counts: { students, trial, activeSubscribers, expiredSubscriptions, pendingPayments, approvedPayments } });
});
app.get('/api/admin/payments', requireAdmin, (req,res) => {
  const status = ['pending','approved','rejected'].includes(req.query.status) ? req.query.status : 'pending';
  const rows = db.prepare(`SELECT p.*, u.profile_json, u.username FROM payments p JOIN users u ON u.telegram_id=p.telegram_id WHERE p.status=? ORDER BY p.created_at DESC LIMIT 100`).all(status);
  res.json({ payments: rows.map(p => {
    const profile = parsedProfile({profile_json:p.profile_json});
    const file = path.join(UPLOAD_DIR,p.receipt_path);
    let receiptDataUrl = '';
    try { receiptDataUrl = `data:${p.receipt_type};base64,${fs.readFileSync(file).toString('base64')}`; } catch {}
    return { id:p.id, telegramId:p.telegram_id, studentName:profile.name || p.username || 'Student', method:p.method, amount:p.amount, txId:p.tx_id, status:p.status, createdAt:p.created_at, receiptDataUrl, reviewedAt:p.reviewed_at, rejectionReason:p.rejection_reason };
  }) });
});
app.post('/api/admin/payments/:id/approve', requireAdmin, (req,res) => {
  const p = db.prepare('SELECT * FROM payments WHERE id=?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'payment_not_found' });
  if (p.status !== 'pending') return res.status(409).json({ error: 'payment_not_pending' });
  const reviewedAt = nowIso(); const expires = plusMs(new Date(), 365*24*60*60*1000);
  const update = db.transaction(() => {
    db.prepare("UPDATE payments SET status='approved', reviewed_at=?, reviewed_by=? WHERE id=? AND status='pending'").run(reviewedAt,req.telegramId,p.id);
    db.prepare('UPDATE users SET subscription_expires_at=? WHERE telegram_id=?').run(expires,p.telegram_id);
  });
  update(); res.json({ ok:true, status:'approved', subscriptionExpiresAt:expires });
});
app.post('/api/admin/payments/:id/reject', requireAdmin, (req,res) => {
  const p = db.prepare('SELECT * FROM payments WHERE id=?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'payment_not_found' });
  if (p.status !== 'pending') return res.status(409).json({ error: 'payment_not_pending' });
  db.prepare("UPDATE payments SET status='rejected', reviewed_at=?, reviewed_by=?, rejection_reason=? WHERE id=? AND status='pending'")
    .run(nowIso(),req.telegramId,String(req.body?.reason||'').slice(0,300),p.id);
  res.json({ ok:true, status:'rejected' });
});

app.use((err,req,res,next) => { console.error(err); res.status(500).json({ error:'server_error' }); });
app.listen(PORT, () => console.log(`Remedial Prep server listening on port ${PORT}`));
