REMEDIAL PREP — UPDATED FILES

WHAT IS INCLUDED
- index.html: updated app UI with 200 ETB / 1-year wording, CBE/Telebirr/Abyssinia selection, required receipt screenshot upload, and admin dashboard UI.
- server.js: backend API with Telegram initData verification, 48-hour trial creation, payment receipt storage, admin-only approval/rejection, and database-backed subscriber statistics.
- package.json: Node.js dependencies.
- .env.example: environment variable template.

IMPORTANT BEFORE LAUNCH
1. This must be hosted as a Node.js app. Do not open index.html as a local file and expect online registration/payment/admin features to work.
2. Set TELEGRAM_BOT_TOKEN to the real BotFather token in the hosting provider's private environment settings. Never publish this token in GitHub or in index.html.
3. Set ADMIN_TELEGRAM_IDS to your numeric Telegram user ID. Do not use your @username. Only this ID can approve or reject payments.
4. Configure a persistent disk and set DATA_DIR to a persistent path. Otherwise the database and receipt screenshots may be lost on redeploy/restart.
5. Update the Telebirr/CBE details in index.html and add the real Abyssinia account number before publishing. The Abyssinia number is intentionally blank because it was not supplied.
6. Set your Telegram bot's Mini App URL to the HTTPS URL of this deployed Node.js app.
7. Students upload screenshots and enter the transaction reference. The admin must confirm the money arrived in the actual bank/Telebirr account before clicking Approve.

API EXPECTATIONS
The included frontend and backend are designed to run on the same origin, so API_URL can remain an empty string. Telegram Web App initData is validated by the server. Admin endpoints require the Telegram ID to be listed in ADMIN_TELEGRAM_IDS.

DEPLOYMENT NOTE
This project has not been deployed or connected to your live Telegram bot from this chat. The app cannot process real payments until you deploy it and configure the environment variables and account details. Keep backups of the persistent database and receipt uploads.
